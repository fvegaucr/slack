    <?php 
      header("Content-Type: text/plain; charset=utf8");
      echo "Hello World\n";
    ?>
